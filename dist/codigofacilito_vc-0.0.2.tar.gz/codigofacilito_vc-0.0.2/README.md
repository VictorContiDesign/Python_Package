### CodigoFacilito

Este paquete nos permite consumir el API de la plataforma.

https://www.geeksforgeeks.org/detect-encoding-of-a-text-file-with-python/